import React, { useState } from 'react';
import AWS from 'aws-sdk';
import { Box, Button, Input, Progress, VStack, Text, useToast } from '@chakra-ui/react';

const S3_BUCKET = 'grocery-receipts-bucket';
const REGION = 'us-east-1';

AWS.config.update({
  region: REGION,
  accessKeyId: "ASIAZLE6M6CY64PU6PVK",
  secretAccessKey: "BXn+bfeS4Q3vfsgroEYmP926ZxffQn+pmmv57G5G",
  sessionToken: "IQoJb3JpZ2luX2VjEMr//////////wEaCXVzLXdlc3QtMiJHMEUCIAxCdzB/9KPTLs2UE4BO5y2y/yvBJ2wrAE2wLjIWlvzOAiEA7hqliTjPSO90/UoixmdW9+BkhQc2agnagmuiAf/SrEYqsgIIw///////////ARAAGgw2NDI0Mjk4MDg4MTciDJEgpyyIIoBTbW3NeiqGAg+C69fCGy6UJtPhqDio2n+aPxAdV8cGC62+uryd2t34IsnyZRjP6MrQaTT3vPYjiYAtf4HqKMKKoTy9UMFUTmDjN8e9GeAUxrJoUm657e5Us16Y26cuRKwlVFK3awqJpf2FEhPGUvEQTDJJU4eIvsCq/aR4h9GN+JKUUpnhSDS0Vk3ZzaG45+UfjkkNK0Wm1iR+gZfuzNHYiV4fn4rhWbp6I+W89ntcbBPNS4d0b+8pjM9LURrQ/0TD87M0oEiI/HTEC9w9rRG8CLnuifXl7P3XOYun+W48mi/YiDfnNBr3hCQGpox89O3qPvTuLqPoGZpTclsODDj9p7SKeUoWeEqFQS/idm0w/eHztQY6nQH4pbGtXivuuwn0u9ZUkzsbCeBejan9+R4fAlg8714vQbX+edJi/sSiH+ZEFyaayOZgUm/0Nk7ZedcVlITih3ftQxL0ylp9N2NpndfKQnXwArV3OlcaoJCat+LeEx3ofPN2HgVRZ545pnAQcwEqXtxQko3w8X8TIY5df8JCF/cDA/fhzMegT1jxs/0y4F2lpnihDqxsz/9L1ycPt95e"
});

const myBucket = new AWS.S3();

const UploadReceipt = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [progress, setProgress] = useState(0);
  const toast = useToast();

  const handleFileInput = (e) => {
    setSelectedFile(e.target.files[0]);
  };

  const uploadFile = (file) => {
    const params = {
      ACL: 'public-read',
      Body: file,
      Bucket: S3_BUCKET,
      Key: file.name,
    };

    myBucket.upload(params)
      .on('httpUploadProgress', (evt) => {
        setProgress(Math.round((evt.loaded / evt.total) * 100));
      })
      .send((err) => {
        if (err) {
          console.log(err);
          toast({
            title: 'Error uploading file.',
            description: err.message,
            status: 'error',
            duration: 3000,
            isClosable: true,
          });
        } else {
          console.log('Successfully uploaded file.');
          toast({
            title: 'File uploaded successfully.',
            status: 'success',
            duration: 3000,
            isClosable: true,
          });
        }
      });
  };

  return (
    <VStack spacing={4} mt={10}>
      <Text fontSize="2xl" fontWeight="bold">Upload Your Grocery Receipt</Text>
      <Input type="file" onChange={handleFileInput} />
      <Button colorScheme="blue" onClick={() => uploadFile(selectedFile)} disabled={!selectedFile}>
        Upload to S3
      </Button>
      {progress > 0 && (
        <Progress value={progress} size="sm" width="100%" colorScheme="green" />
      )}
    </VStack>
  );
};

export default UploadReceipt;
